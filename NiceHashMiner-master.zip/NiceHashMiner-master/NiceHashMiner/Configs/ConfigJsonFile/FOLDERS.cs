﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NiceHashMiner.Configs.ConfigJsonFile {
    public static class FOLDERS {
        public static readonly string CONFIG = @"configs\";
        public static readonly string INTERNALS = @"internals\";
    }
}
