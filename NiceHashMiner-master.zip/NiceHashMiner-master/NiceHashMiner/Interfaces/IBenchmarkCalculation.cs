﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NiceHashMiner.Interfaces {
    public interface IBenchmarkCalculation {
        void CalcBenchmarkDevicesAlgorithmQueue();
    }
}
