﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace NiceHashMiner.Interfaces {
    public interface IListItemCheckColorSetter {
        void LviSetColor(ListViewItem lvi);
    }
}
