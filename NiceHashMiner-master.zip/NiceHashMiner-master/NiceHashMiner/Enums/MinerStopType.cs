﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NiceHashMiner.Enums {
    public enum MinerStopType {
        SWITCH,
        END,
        FORCE_END
    }
}
