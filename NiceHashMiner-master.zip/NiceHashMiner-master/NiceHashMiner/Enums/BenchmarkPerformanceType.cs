﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NiceHashMiner.Enums
{
    public enum BenchmarkPerformanceType : int
    {
        Quick = 0,
        Standard,
        Precise
    }
}
