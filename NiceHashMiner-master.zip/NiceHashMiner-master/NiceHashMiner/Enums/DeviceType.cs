﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NiceHashMiner.Enums {
    public enum DeviceType {
        CPU = 0,
        NVIDIA,
        AMD
    }
}
