﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NiceHashMiner.Enums
{
    public enum LanguageType : int
    {
        //NONE = -1,
        En = 0,
        Ru,
        Es
    }
}
