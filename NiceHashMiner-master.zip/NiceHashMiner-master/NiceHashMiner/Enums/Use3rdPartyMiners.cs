﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NiceHashMiner.Enums {
    public enum Use3rdPartyMiners {
        NOT_SET = 0,
        NO,
        YES
    }
}
