# CudaDeviceDetection

CudaDeviceDetection is a win32 program that prints avaliable CUDA GPU devices in JSON format. In order to compile this project **CUDA SDK 8.0** is needed. Supports Windows x64 only. 